// background.js - service worker
const recordedTabs = new Set();

// Obsługa komunikatów z panelu DevTools lub content scriptów
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.cmd === 'start-record') {
    // Rozpoczęcie nagrywania – zapamiętaj kartę i wstrzyknij content script
    recordedTabs.add(request.tabId);
    chrome.scripting.executeScript({
      target: { tabId: request.tabId },
      files: ['contentScript.js']
    });
    sendResponse({ started: true });
  }
  else if (request.cmd === 'stop-record') {
    // Zakończenie nagrywania – usuń kartę z nagrywanych i wyślij polecenie stop do content scriptu
    recordedTabs.delete(request.tabId);
    chrome.tabs.sendMessage(request.tabId, { command: 'stopRecording' });
  }
  else if (request.cmd === 'start-selection') {
    // Wejście w tryb wyboru elementu do screenshota
    if (!recordedTabs.has(request.tabId)) {
      // Jeśli content script jeszcze nie był wstrzyknięty, zrób to teraz
      recordedTabs.add(request.tabId);
      chrome.scripting.executeScript({
        target: { tabId: request.tabId },
        files: ['contentScript.js']
      }, () => {
        chrome.tabs.sendMessage(request.tabId, {
          command: 'enableSelectionMode',
          screenshotIndex: request.index
        });
      });
    } else {
      // Content script działa – wyślij polecenie zaznaczania elementu
      chrome.tabs.sendMessage(request.tabId, {
        command: 'enableSelectionMode',
        screenshotIndex: request.index
      });
    }
  }
  else if (request.cmd === 'exportTest') {
    // Zapisz wygenerowany kod testu do pliku .spec.ts
    const blob = new Blob([request.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({
      url: url,
      filename: 'recorded-test.spec.ts'
    });
  }
  else if (request.cmd === 'saveScreenshot') {
    // Zapisz zrzut ekranu (obraz w formacie data URL) do pliku PNG
    chrome.downloads.download({
      url: request.dataUrl,
      filename: `element-${request.index}.png`
    }, () => {
      // Powiadom panel DevTools, by dodał krok testu z oczekiwaniem na snapshot
      chrome.runtime.sendMessage({
        type: 'screenshotSaved',
        tabId: sender.tab.id,
        selector: request.selector,
        index: request.index
      });
    });
  }
  else if (request.cmd === 'captureElement') {
    // Wykonaj screenshot widocznej części karty i zwróć go jako dataURL
    const tabId = sender.tab.id;
    chrome.tabs.get(tabId, (tab) => {
      chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' }, (dataUrl) => {
        sendResponse({ imgSrc: dataUrl });
      });
    });
    return true; // utrzymaj port do czasu wywołania sendResponse
  }
});

// Nasłuchiwanie nawigacji – ponowne wstrzyknięcie content scriptu i rejestracja kroku nawigacji
chrome.webNavigation.onDOMContentLoaded.addListener(details => {
  if (recordedTabs.has(details.tabId) && details.frameId === 0) {
    // Strona przeładowana/nawigacja w głównym oknie – wstrzyknij ponownie content script
    chrome.scripting.executeScript({
      target: { tabId: details.tabId },
      files: ['contentScript.js']
    });
  }
});
chrome.webNavigation.onCommitted.addListener(details => {
  if (recordedTabs.has(details.tabId) && details.frameId === 0) {
    // Wyślij do panelu DevTools informację o zmianie URL (nawigacji głównej ramki)
    chrome.runtime.sendMessage({
      type: 'navigation',
      tabId: details.tabId,
      url: details.url
    });
  }
});
