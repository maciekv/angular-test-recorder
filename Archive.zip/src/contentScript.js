// contentScript.js
(() => {
  let isRecording = true;
  let selectionMode = false;
  let pendingScreenshotIndex = null;

  // Funkcja generująca stabilny selektor CSS dla elementu
  function getSelector(el) {
    if (!el) return '';
    // Preferowane atrybuty:
    if (el.getAttribute('data-testid')) {
      return `[data-testid="${el.getAttribute('data-testid')}"]`;
    }
    if (el.id) {
      return '#' + el.id;
    }
    if (el.getAttribute('aria-label')) {
      return `[aria-label="${el.getAttribute('aria-label')}"]`;
    }
    // Domyślnie buduj selektor wg hierarchii DOM:
    const tag = el.tagName.toLowerCase();
    if (!el.parentElement) {
      return tag;
    }
    const siblings = el.parentElement.children;
    let sameTagCount = 0;
    let index = 0;
    for (let i = 0; i < siblings.length; i++) {
      if (siblings[i].tagName.toLowerCase() === tag) {
        sameTagCount++;
        if (siblings[i] === el) {
          index = sameTagCount;
        }
      }
    }
    const parentSelector = getSelector(el.parentElement);
    if (sameTagCount === 1) {
      return `${parentSelector} > ${tag}`;
    } else {
      return `${parentSelector} > ${tag}:nth-child(${index})`;
    }
  }

  // Wykryj Angular Testability (czy na stronie jest Angular)
  const hasAngular = (typeof window.getAllAngularTestabilities === 'function');
  chrome.runtime.sendMessage({ type: 'angularDetected', value: hasAngular });

  // Nasłuchiwanie poleceń z background (sterowanych przez panel DevTools)
  chrome.runtime.onMessage.addListener(msg => {
    if (msg.command === 'stopRecording') {
      // Zatrzymaj nagrywanie – wyłącz wysyłanie zdarzeń
      isRecording = false;
      document.removeEventListener('click', handleClick, true);
      document.removeEventListener('change', handleChange, true);
    }
    if (msg.command === 'enableSelectionMode') {
      // Wejdź w tryb wyboru elementu do screenshota
      selectionMode = true;
      pendingScreenshotIndex = msg.screenshotIndex;
      // Dodaj podświetlanie elementów przy najechaniu kursorem
      document.addEventListener('mouseover', hoverHighlight, true);
      document.addEventListener('mouseout', removeHighlight, true);
    }
  });

  // Podświetlanie elementu przy hover (pomoc w trybie wyboru elementu)
  function hoverHighlight(e) {
    e.target.style.outline = '2px solid red';
  }
  function removeHighlight(e) {
    e.target.style.outline = '';
  }

  // Obsługa kliknięć na stronie
  function handleClick(e) {
    if (!isRecording) return;
    if (selectionMode) {
      // Tryb zaznaczania elementu do screenshota
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      // Wyłącz podświetlanie po wyborze
      document.removeEventListener('mouseover', hoverHighlight, true);
      document.removeEventListener('mouseout', removeHighlight, true);
      selectionMode = false;
      // Pobierz szczegóły elementu i jego położenie
      const el = e.target;
      const selector = getSelector(el);
      const rect = el.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const left = rect.left, top = rect.top;
      const width = rect.width, height = rect.height;
      // Poproś background o pełny zrzut ekranu widocznej części
      chrome.runtime.sendMessage({ cmd: 'captureElement' }, response => {
        if (response && response.imgSrc) {
          // Załaduj obraz i przytnij do wybranego elementu
          const image = new Image();
          image.src = response.imgSrc;
          image.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = width * dpr;
            canvas.height = height * dpr;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(
              image,
              left * dpr, top * dpr, width * dpr, height * dpr,
              0, 0, width * dpr, height * dpr
            );
            const croppedDataUrl = canvas.toDataURL('image/png');
            // Wyślij przycięty obraz do background w celu zapisania
            chrome.runtime.sendMessage({
              cmd: 'saveScreenshot',
              index: pendingScreenshotIndex,
              selector: selector,
              dataUrl: croppedDataUrl
            });
          };
        }
      });
    } else {
      // Tryb normalnego nagrywania kliknięcia
      const targetEl = e.target;
      const selector = getSelector(targetEl);
      // Jeśli kliknięto link (anchor), pobierz jego href (o ile nie otwiera w nowej karcie)
      let href = null;
      const anchor = targetEl.closest('a');
      if (anchor && anchor.href && (!anchor.target || anchor.target === "_self")) {
        href = anchor.href;
      }
      chrome.runtime.sendMessage({
        type: 'click',
        selector: selector,
        href: href
      });
    }
  }

  // Obsługa zmian w polach formularza (wpisywanie tekstu, wybór)
  function handleChange(e) {
    if (!isRecording) return;
    const target = e.target;
    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT') {
      const selector = getSelector(target);
      const value = target.value;
      chrome.runtime.sendMessage({
        type: 'input',
        selector: selector,
        value: value
      });
    }
  }

  // Podłącz globalne nasłuchiwanie zdarzeń kliknięcia i zmiany
  document.addEventListener('click', handleClick, true);
  document.addEventListener('change', handleChange, true);
})();
