(() => {
  const tabId = chrome.devtools.inspectedWindow.tabId;
  let angularDetected = false;
  let lastClickHref = null;
  let screenshotCounter = 0;
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const snapshotBtn = document.getElementById('snapshotBtn');
  const exportBtn = document.getElementById('exportBtn');
  const thresholdInput = document.getElementById('thresholdInput');
  const stepsList = document.getElementById('stepsList');
  const recordedSteps = [];

  function addStep(stepText) {
    recordedSteps.push(stepText);
    const li = document.createElement('li');
    li.textContent = stepText;
    stepsList.appendChild(li);
  }

  chrome.runtime.onMessage.addListener(message => {
    if (message.tabId && message.tabId !== tabId) return;
    switch (message.type) {
      case 'angularDetected':
        angularDetected = message.value;
        break;
      case 'click':
        addStep(`await page.click('${message.selector}');`);
        if (message.href) {
          lastClickHref = message.href;
        } else {
          lastClickHref = null;
        }
        if (angularDetected) {
          addStep(`await page.waitForFunction(() => {
  const t = window.getAllAngularTestabilities;
  return !t || t().every(x => x.isStable());
});`);
        }
        break;
      case 'input':
        const valStr = JSON.stringify(message.value);
        addStep(`await page.fill('${message.selector}', ${valStr});`);
        if (angularDetected) {
          addStep(`await page.waitForFunction(() => {
  const t = window.getAllAngularTestabilities;
  return !t || t().every(x => x.isStable());
});`);
        }
        break;
      case 'navigation':
        if (lastClickHref && message.url === lastClickHref) {
          lastClickHref = null;
        } else {
          addStep(`await page.goto('${message.url}');`);
        }
        break;
      case 'screenshotSaved':
        const thr = parseFloat(thresholdInput.value) || 0.1;
        addStep(`expect(await page.locator('${message.selector}').screenshot()).toMatchSnapshot('element-${message.index}.png', { threshold: ${thr} });`);
        break;
    }
  });

  startBtn.addEventListener('click', () => {
    recordedSteps.length = 0;
    stepsList.innerHTML = '';
    chrome.runtime.sendMessage({ cmd: 'start-record', tabId: tabId }, () => {
      chrome.devtools.inspectedWindow.eval("location.href", (result) => {
        if (result) addStep(`await page.goto('${result}');`);
      });
    });
    startBtn.disabled = true;
    stopBtn.disabled = false;
  });

  stopBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ cmd: 'stop-record', tabId: tabId });
    startBtn.disabled = false;
    stopBtn.disabled = true;
  });

  snapshotBtn.addEventListener('click', () => {
    screenshotCounter++;
    chrome.runtime.sendMessage({ cmd: 'start-selection', tabId: tabId, index: screenshotCounter });
  });

  exportBtn.addEventListener('click', () => {
    let testContent = "import { test, expect } from '@playwright/test';\n\n";
    testContent += "test('Recorded test', async ({ page }) => {\n";
    for (const step of recordedSteps) testContent += "  " + step + "\n";
    testContent += "});\n";
    chrome.runtime.sendMessage({ cmd: 'exportTest', tabId: tabId, content: testContent });
  });
})();
